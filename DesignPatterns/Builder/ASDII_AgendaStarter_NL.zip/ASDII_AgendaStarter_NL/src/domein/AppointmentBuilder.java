package domein;

import java.time.LocalDateTime;
import java.util.*;

import exception.InformationRequiredException;

import java.time.*;

public class AppointmentBuilder {

	protected Appointment appointment;

	protected Set<RequiredElement> requiredElements;

	public Appointment getAppointment() throws InformationRequiredException {
		requiredElements = new HashSet<>();
		if (appointment.getStartDate()==null) {
			requiredElements.add(RequiredElement.StartDateRequired);
		}
		if (appointment.getLocation()==null) {
			requiredElements.add(RequiredElement.LocationRequired);
		}
		if (appointment.getAttendees().isEmpty()) {
			requiredElements.add(RequiredElement.AttendeeRequired);
		}
		if (!requiredElements.isEmpty()) {
			throw new InformationRequiredException(requiredElements);
		}
		return this.appointment;
	}

	public void createAppointment() {
		appointment = new Appointment();
	}

	public void buildDescription(String description) {
		appointment.setDescription(description);
	}

	public void buildLocation(Location location) {
		appointment.setLocation(location);
	}

	public void buildAttendees(List<domein.Contact> attendees) {
		appointment.setAttendees(attendees);
	}

	public void buildDates(LocalDateTime startDate, LocalDateTime endDate) {
		if (startDate!=null && startDate.isAfter(LocalDateTime.now())) {
			appointment.setStartDate(startDate);
			if (endDate!=null && endDate.isAfter(startDate)) {
				appointment.setEndDate(endDate);
			}
		}
	}

}
