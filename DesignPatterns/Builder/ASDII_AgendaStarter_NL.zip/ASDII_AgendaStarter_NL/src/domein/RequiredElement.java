package domein;

public enum RequiredElement {

    StartDateRequired, EndDateRequired, 
    DescriptionRequired, AttendeeRequired, LocationRequired;
}
